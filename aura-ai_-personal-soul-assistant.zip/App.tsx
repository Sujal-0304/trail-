
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Calendar, 
  Mail, 
  Linkedin, 
  LayoutDashboard, 
  Bell, 
  CheckCircle2, 
  Plus, 
  LogOut,
  Send,
  X,
  Clock,
  Briefcase,
  AlertCircle,
  Sparkles,
  User,
  Camera,
  Lock,
  RefreshCw,
  Brain,
  KeyRound,
  ShieldCheck,
  ChevronLeft,
  AtSign,
  ExternalLink,
  Check,
  Link as LinkIcon,
  Shield
} from 'lucide-react';
import { UserProfile, Task, Email, LinkedInUpdate } from './types';
import { planDay, categorizeEmails, generateLinkedInInsights } from './services/geminiService';
import { auraDB } from './services/databaseService';
import VoiceAura from './components/VoiceAura';
import ReminderSystem from './components/ReminderSystem';
import ChatAura from './components/ChatAura';

// --- MOCK DATA ---
const INITIAL_EMAILS = [
  { id: '1', sender: 'Boss', subject: 'Q4 Review', content: 'Hey, can we sync on the Q4 numbers later today?', timestamp: new Date().toISOString() },
  { id: '2', sender: 'Sale Bot', subject: 'HUGE DISCOUNTS!!!', content: 'Buy now or lose forever! Best deals in town.', timestamp: new Date().toISOString() },
  { id: '3', sender: 'HR', subject: 'New Training', content: 'Please complete your security training by Friday.', timestamp: new Date().toISOString() },
  { id: '4', sender: 'Project Manager', subject: 'Timeline Update', content: 'The client moved the deadline. Are we ready for the launch?', timestamp: new Date().toISOString() },
];

const INITIAL_TASKS: Task[] = [
  { id: 't1', title: 'Morning Coffee & Briefing', startTime: new Date(Date.now() + 600000).toISOString(), endTime: new Date(Date.now() + 1800000).toISOString(), category: 'work', completed: false },
  { id: 't2', title: 'LinkedIn Job Hunt', startTime: new Date(Date.now() + 3600000).toISOString(), endTime: new Date(Date.now() + 5400000).toISOString(), category: 'work', completed: false },
  { id: 't3', title: 'Gym Session', startTime: new Date(Date.now() + 14400000).toISOString(), endTime: new Date(Date.now() + 18000000).toISOString(), category: 'health', completed: false },
];

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<'dash' | 'calendar' | 'email' | 'linkedin' | 'chat'>('dash');
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [emails, setEmails] = useState<Email[]>([]);
  const [linkedinData, setLinkedinData] = useState<LinkedInUpdate[]>([]);
  const [dailyPlan, setDailyPlan] = useState<string>('Asking Aura to prepare your plan...');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Login State
  const [loginName, setLoginName] = useState('');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginMode, setLoginMode] = useState<'login' | 'forgot' | 'recovery_sent' | 'reset'>('login');
  const [emailPermission, setEmailPermission] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Live Clock Effect
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Persistent Login Check
  useEffect(() => {
    const activeSession = localStorage.getItem('aura_active_session_name');
    if (activeSession) {
      auraDB.getUser(activeSession).then(profile => {
        if (profile) setUser(profile);
      });
    }
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    if (!loginName.trim()) return;

    let profile = await auraDB.getUser(loginName);

    if (profile) {
      if (profile.password !== loginPass) {
        setLoginError("Incorrect password for this user.");
        return;
      }
      profile.memories = [
        ...profile.memories.filter(m => !m.includes('Last seen')),
        `Last seen on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`
      ];
      await auraDB.saveUser(profile);
    } else {
      // New user registration
      if (!loginEmail.trim()) {
        setLoginError("Please provide an Email address to register.");
        return;
      }
      if (!emailPermission) {
        setLoginError("Please grant Aura permission to read and draft emails to proceed.");
        return;
      }
      profile = {
        name: loginName,
        email: loginEmail,
        password: loginPass,
        avatar: selectedAvatar || undefined,
        role: 'Creative Professional',
        preferences: ['Early riser', 'Coffee enthusiast'],
        memories: [
          `Joined Aura on ${new Date().toLocaleDateString()}`,
          `Primary contact: ${loginEmail}`,
          `Email automation enabled`
        ],
        integrations: {
          google: false,
          linkedin: false
        }
      };
      await auraDB.saveUser(profile);
    }

    localStorage.setItem('aura_active_session_name', profile.name);
    setUser(profile);
  };

  const handleToggleIntegration = async (service: 'google' | 'linkedin') => {
    if (!user) return;
    const updatedUser = { ...user };
    if (!updatedUser.integrations) updatedUser.integrations = { google: false, linkedin: false };
    updatedUser.integrations[service] = !updatedUser.integrations[service];
    
    // Simulate memory of integration
    const status = updatedUser.integrations[service] ? 'Connected' : 'Disconnected';
    updatedUser.memories.push(`${service} API ${status} on ${new Date().toLocaleTimeString()}`);
    
    await auraDB.saveUser(updatedUser);
    setUser(updatedUser);
    syncAura();
  };

  const handleForgotPasswordRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const profile = await auraDB.getUser(loginName);
    if (!profile) {
      setLoginError("No account found with that username.");
      return;
    }
    setLoginEmail(profile.email);
    setLoginMode('recovery_sent');
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const profile = await auraDB.getUser(loginName);
    if (profile) {
      profile.password = loginPass;
      await auraDB.saveUser(profile);
      setLoginMode('login');
      setLoginPass('');
      alert("Password reset successful.");
    }
  };

  const handleUpdateMemory = async (fact: string) => {
    if (!user) return;
    const updatedUser = await auraDB.updateMemory(user.name, fact);
    if (updatedUser) setUser(updatedUser);
  };

  const handleLogout = () => {
    localStorage.removeItem('aura_active_session_name');
    setUser(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedAvatar(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleToolCall = async (name: string, args: any) => {
    console.log(`Tool Call: ${name}`, args);
    switch (name) {
      case 'scheduleTask':
        const newTask: Task = { id: Math.random().toString(36).substr(2, 9), ...args, completed: false };
        setTasks(prev => [...prev, newTask]);
        return { result: "Task scheduled successfully." };
      case 'sendEmail':
        alert(`Aura is sending email to ${args.recipient}\nSubject: ${args.subject}`);
        return { result: "Email dispatched." };
      case 'getProfessionalUpdates':
        syncAura();
        return { result: "LinkedIn insights refreshed." };
      case 'navigateToTab':
        setActiveTab(args.tab);
        return { result: `Navigated to ${args.tab}` };
      case 'updateUserMemory':
        handleUpdateMemory(args.fact);
        return { result: "Memory updated." };
      default:
        return { result: "Unknown action." };
    }
  };

  const syncAura = async () => {
    if (!user || isSyncing) return;
    setIsSyncing(true);
    setSyncError(null);
    
    try {
      const plan = await planDay(user, tasks);
      setDailyPlan(plan);
      
      // Simulate API fetch based on integration status
      if (user.integrations?.google) {
        const categorized = await categorizeEmails(INITIAL_EMAILS);
        setEmails(categorized);
      } else {
        setEmails([]);
      }

      if (user.integrations?.linkedin) {
        const linkedin = await generateLinkedInInsights(user);
        setLinkedinData(linkedin.updates);
      } else {
        setLinkedinData([]);
      }
      
    } catch (err: any) {
      console.error('Sync error:', err);
      setSyncError("Neural frequency busy. Aura is catching her breath.");
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    if (user) syncAura();
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900 via-slate-950 to-black overflow-hidden">
        <div className="max-w-lg w-full glass p-10 rounded-[3rem] shadow-2xl space-y-8 relative animate-in fade-in zoom-in-95 duration-700">
          <div className="absolute -top-20 -left-20 w-64 h-64 bg-indigo-600/20 blur-[100px] rounded-full" />
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-5 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl shadow-xl shadow-indigo-500/30">
              <Sparkles className="w-10 h-10 text-white" />
            </div>
            <div className="space-y-1">
              <h1 className="text-4xl font-black font-outfit tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                {loginMode === 'login' ? 'Personal Aura' : 'Neural Recovery'}
              </h1>
              <p className="text-slate-400 font-medium">
                {loginMode === 'login' ? 'IDENTIFY TO WAKE YOUR ASSISTANT.' : 'RESTORING YOUR NEURAL ACCESS.'}
              </p>
            </div>
          </div>

          {loginMode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="flex flex-col items-center gap-4">
                <div onClick={() => fileInputRef.current?.click()} className="w-20 h-20 rounded-full bg-slate-800 border-2 border-dashed border-slate-700 hover:border-indigo-500 transition-all cursor-pointer overflow-hidden flex items-center justify-center group relative">
                  {selectedAvatar ? (
                    <img src={selectedAvatar} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <Camera className="w-8 h-8 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                  )}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <span className="text-[8px] font-bold uppercase text-white text-center px-1">Upload Portrait</span>
                  </div>
                </div>
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
              </div>
              <div className="space-y-3">
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                  <input type="text" placeholder="Username" required className="w-full bg-slate-900/50 border border-slate-800 rounded-xl pl-10 pr-6 py-3.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white text-sm" value={loginName} onChange={(e) => setLoginName(e.target.value)} />
                </div>
                <div className="relative group">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                  <input type="password" placeholder="Password" required className="w-full bg-slate-900/50 border border-slate-800 rounded-xl pl-10 pr-6 py-3.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white text-sm" value={loginPass} onChange={(e) => setLoginPass(e.target.value)} />
                </div>
                <div className="relative group">
                  <AtSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                  <input type="email" placeholder="Email" className="w-full bg-slate-900/50 border border-slate-800 rounded-xl pl-10 pr-6 py-3.5 outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white text-sm" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} />
                </div>
                <div className="flex items-center gap-3 px-2 py-1">
                   <button 
                     type="button" 
                     onClick={() => setEmailPermission(!emailPermission)}
                     className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${emailPermission ? 'bg-indigo-600 border-indigo-600' : 'border-slate-700 bg-slate-900/50'}`}
                   >
                     {emailPermission && <Check className="w-3 h-3 text-white" />}
                   </button>
                   <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-tight">Allow Aura to manage external APIs (Email/Calendar)</span>
                </div>
                {loginError && <p className="text-red-400 text-[10px] font-bold text-center px-4">{loginError}</p>}
              </div>
              <div className="flex flex-col gap-3">
                <button className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-xl transition-all shadow-xl shadow-indigo-500/20 active:scale-[0.98]">WAKE AURA</button>
                <button type="button" onClick={() => { setLoginMode('forgot'); setLoginError(null); }} className="text-slate-500 hover:text-indigo-400 text-[10px] font-black uppercase tracking-widest transition-colors text-center">Forgot Access Key?</button>
              </div>
            </form>
          )}

          {loginMode === 'forgot' && (
            <form onSubmit={handleForgotPasswordRequest} className="space-y-6 animate-in slide-in-from-right-4">
              <div className="space-y-4 text-center">
                <p className="text-xs text-slate-400 leading-relaxed px-6">Enter your username below. Aura will dispatch a recovery signal.</p>
                <div className="relative group text-left">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                  <input type="text" placeholder="Username" required className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-12 pr-6 py-4 outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white placeholder:text-slate-600" value={loginName} onChange={(e) => setLoginName(e.target.value)} />
                </div>
                {loginError && <p className="text-red-400 text-xs font-bold px-4">{loginError}</p>}
              </div>
              <div className="flex flex-col gap-3">
                <button className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-2xl transition-all shadow-xl shadow-indigo-500/20">Send Recovery Email</button>
                <button type="button" onClick={() => setLoginMode('login')} className="flex items-center justify-center gap-2 text-slate-500 hover:text-white text-xs font-bold transition-colors">
                  <ChevronLeft className="w-4 h-4" /> Back
                </button>
              </div>
            </form>
          )}

          {loginMode === 'recovery_sent' && (
            <div className="space-y-8 animate-in slide-in-from-bottom-4 text-center">
               <Mail className="w-12 h-12 text-indigo-400 mx-auto" />
               <h3 className="text-lg font-bold text-white">Signal Dispatched</h3>
               <p className="text-xs text-slate-400">Check your terminal at {loginEmail.replace(/(.{2})(.*)(?=@)/, '$1***')}</p>
               <button onClick={() => setLoginMode('reset')} className="w-full bg-indigo-600 py-4 rounded-xl font-bold">Reset Password</button>
            </div>
          )}

          {loginMode === 'reset' && (
            <form onSubmit={handleResetPassword} className="space-y-6 animate-in slide-in-from-right-4">
              <div className="relative group">
                <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input type="password" placeholder="New Password" required className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-12 pr-6 py-4 outline-none text-white" value={loginPass} onChange={(e) => setLoginPass(e.target.value)} />
              </div>
              <button className="w-full bg-indigo-600 py-4 rounded-2xl font-bold">Update Key</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-100 selection:bg-indigo-500/30">
      <ReminderSystem tasks={tasks} />
      <aside className="w-20 md:w-72 border-r border-slate-800 flex flex-col p-6 space-y-8 glass shrink-0">
        <div className="flex items-center gap-4 px-2">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20"><Sparkles className="w-6 h-6 text-white" /></div>
          <span className="text-2xl font-bold font-outfit hidden md:block tracking-tight">Aura</span>
        </div>
        
        <div className="hidden md:flex flex-col gap-4 p-4 rounded-3xl bg-slate-900/50 border border-slate-800">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 border border-slate-700 flex items-center justify-center font-bold overflow-hidden shrink-0">
               {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : user.name[0]}
             </div>
             <div className="min-w-0">
               <p className="text-xs font-bold text-white truncate">{user.name}</p>
               <p className="text-[8px] text-slate-500 uppercase font-black truncate">{user.email}</p>
             </div>
           </div>
           <button onClick={handleLogout} className="flex items-center gap-2 w-full p-2 text-[10px] font-black uppercase text-slate-500 hover:text-red-400 transition-all group">
             <LogOut className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform" />
             <span>Sleep Aura</span>
           </button>
        </div>

        <nav className="flex-1 space-y-2">
          <NavItem icon={<LayoutDashboard />} label="Dashboard" active={activeTab === 'dash'} onClick={() => setActiveTab('dash')} />
          <NavItem icon={<Brain />} label="Neural Link" active={activeTab === 'chat'} onClick={() => setActiveTab('chat')} />
          <NavItem icon={<Calendar />} label="Schedule" active={activeTab === 'calendar'} onClick={() => setActiveTab('calendar')} />
          <NavItem icon={<Mail />} label="Inbox" active={activeTab === 'email'} onClick={() => setActiveTab('email')} />
          <NavItem icon={<Linkedin />} label="Professional" active={activeTab === 'linkedin'} onClick={() => setActiveTab('linkedin')} />
        </nav>

        <div className="pt-6 border-t border-slate-800 opacity-20 hover:opacity-100 transition-opacity">
           <p className="text-[10px] text-center font-black uppercase text-slate-600 tracking-tighter">Database Synced v1.2</p>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <header className="sticky top-0 z-20 glass px-10 py-6 flex flex-col sm:flex-row justify-between items-center gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-left">
            <div className="space-y-1">
              <h2 className="text-2xl font-bold font-outfit text-white">Aura Core</h2>
              <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" /><p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">Neural Engine v2.5</p></div>
            </div>
            <div className="hidden md:flex flex-col">
               <span className="text-lg font-bold font-mono text-indigo-400">{currentTime.toLocaleTimeString()}</span>
               <span className="text-[10px] text-slate-500 font-bold uppercase">{currentTime.toLocaleDateString()}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
             {/* Voice Aura prominently at the top */}
             <div className="bg-slate-900/40 p-1 rounded-full border border-slate-800 shadow-inner">
               <VoiceAura user={user} onNavigate={setActiveTab} onUpdateMemory={handleUpdateMemory} onToolCall={handleToolCall} />
             </div>

             <div className="flex items-center gap-4 border-l border-slate-800 pl-6">
                <div className="flex gap-2">
                   <div className={`p-2 rounded-lg border ${user.integrations?.google ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/5' : 'border-slate-800 text-slate-600'}`} title="Google API Status">
                     <AtSign className="w-4 h-4" />
                   </div>
                   <div className={`p-2 rounded-lg border ${user.integrations?.linkedin ? 'border-indigo-500/30 text-indigo-400 bg-indigo-500/5' : 'border-slate-800 text-slate-600'}`} title="LinkedIn API Status">
                     <Linkedin className="w-4 h-4" />
                   </div>
                </div>
                <button onClick={syncAura} disabled={isSyncing} className={`p-3 rounded-2xl glass hover:bg-slate-800 transition-colors ${isSyncing ? 'text-indigo-400 animate-spin' : 'text-slate-400'}`}>
                  <RefreshCw className="w-5 h-5" />
                </button>
             </div>
          </div>
        </header>

        <div className="p-10 max-w-6xl mx-auto space-y-10">
          {activeTab === 'chat' && <ChatAura user={user} onUpdateMemory={handleUpdateMemory} onToolCall={handleToolCall} />}
          
          {activeTab === 'dash' && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
              <div className="lg:col-span-3 space-y-10">
                <section className="glass p-12 rounded-[3.5rem] relative overflow-hidden group border-indigo-500/10 shadow-2xl">
                   <h3 className="text-xl font-bold mb-8 flex items-center gap-3 text-white"><Clock className="w-5 h-5 text-indigo-400" />Today's Sequence</h3>
                   <div className="prose prose-invert prose-indigo max-w-none">
                     <p className="whitespace-pre-wrap text-slate-300 leading-relaxed text-lg">{dailyPlan}</p>
                   </div>
                </section>
                
                <section className="space-y-6">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2 px-4"><LayoutDashboard className="w-5 h-5 text-indigo-400" />Task Queue</h3>
                  <div className="grid gap-4">
                    {tasks.map(task => (
                      <TaskRow key={task.id} task={task} onToggle={(id) => setTasks(prev => prev.map(t => t.id === id ? {...t, completed: !t.completed} : t))} />
                    ))}
                  </div>
                </section>
              </div>

              <div className="space-y-8">
                 <section className="glass p-8 rounded-[3rem] border-indigo-500/20">
                    <h3 className="text-xs font-black uppercase text-indigo-400 mb-6 flex items-center gap-2"><LinkIcon className="w-4 h-4" /> Service Integrations</h3>
                    <div className="space-y-4">
                       <IntegrationToggle 
                         label="Google Workspace" 
                         connected={!!user.integrations?.google} 
                         onToggle={() => handleToggleIntegration('google')} 
                         icon={<AtSign className="w-4 h-4" />}
                       />
                       <IntegrationToggle 
                         label="LinkedIn API" 
                         connected={!!user.integrations?.linkedin} 
                         onToggle={() => handleToggleIntegration('linkedin')} 
                         icon={<Linkedin className="w-4 h-4" />}
                       />
                    </div>
                 </section>
                 
                 <section className="bg-indigo-900/10 p-8 rounded-[3rem] border border-indigo-500/10">
                    <h3 className="text-xs font-black uppercase text-indigo-400 mb-4 flex items-center gap-2"><Shield className="w-4 h-4" /> Security Log</h3>
                    <p className="text-[10px] text-slate-500 leading-relaxed">System healthy. {user.memories.length} neural points stored in IndexedDB.</p>
                 </section>
              </div>
            </div>
          )}

          {activeTab === 'email' && (
            <div className="space-y-8">
              {!user.integrations?.google ? (
                <IntegrationRequired service="Google Workspace" onConnect={() => handleToggleIntegration('google')} />
              ) : (
                <div className="grid gap-6">
                  {emails.map(email => (<EmailCard key={email.id} email={email} />))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'linkedin' && (
            <div className="space-y-8">
               {!user.integrations?.linkedin ? (
                <IntegrationRequired service="LinkedIn Professional" onConnect={() => handleToggleIntegration('linkedin')} />
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-6">
                    <h3 className="text-xl font-bold flex items-center gap-3"><Briefcase className="w-5 h-5 text-indigo-400" /> Opportunities</h3>
                    {linkedinData.filter(u => u.type === 'job').map(job => (<LinkedInCard key={job.id} item={job} />))}
                  </div>
                  <div className="space-y-6">
                    <h3 className="text-xl font-bold flex items-center gap-3"><Bell className="w-5 h-5 text-indigo-400" /> Notifications</h3>
                    {linkedinData.filter(u => u.type === 'notification').map(notif => (<LinkedInCard key={notif.id} item={notif} />))}
                  </div>
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'calendar' && (
            <div className="glass p-20 rounded-[4rem] text-center space-y-6">
              <Calendar className="w-16 h-16 text-indigo-500 mx-auto" />
              <h3 className="text-2xl font-bold text-white">Calendar Visualizer</h3>
              <p className="text-slate-400 max-w-md mx-auto">Aura is managing your schedule via her neural core. Events are synced and alerts are primed.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

const IntegrationToggle: React.FC<{ label: string, connected: boolean, onToggle: () => void, icon: React.ReactNode }> = ({ label, connected, onToggle, icon }) => (
  <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900 border border-slate-800">
    <div className="flex items-center gap-3 text-slate-300">
      {icon}
      <span className="text-xs font-bold">{label}</span>
    </div>
    <button 
      onClick={onToggle} 
      className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase transition-all ${connected ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'bg-slate-800 text-slate-500'}`}
    >
      {connected ? 'Connected' : 'Link API'}
    </button>
  </div>
);

const IntegrationRequired: React.FC<{ service: string, onConnect: () => void }> = ({ service, onConnect }) => (
  <div className="glass p-20 rounded-[4rem] text-center space-y-8 animate-in fade-in zoom-in-95">
    <div className="w-20 h-20 bg-indigo-500/10 rounded-[2.5rem] flex items-center justify-center mx-auto">
      <LinkIcon className="w-10 h-10 text-indigo-500" />
    </div>
    <div className="space-y-2">
      <h3 className="text-2xl font-bold text-white">Connection Required</h3>
      <p className="text-slate-400 max-w-sm mx-auto leading-relaxed text-sm">Aura needs access to your {service} API to manage your data and generate neural drafts.</p>
    </div>
    <button onClick={onConnect} className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-10 py-4 rounded-2xl transition-all shadow-xl shadow-indigo-500/20">
      Establish API Link
    </button>
  </div>
);

const NavItem: React.FC<{ icon: React.ReactNode, label: string, active: boolean, onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button onClick={onClick} className={`flex items-center gap-4 w-full p-4 rounded-2xl transition-all duration-500 group ${active ? 'bg-indigo-600 text-white shadow-2xl shadow-indigo-500/30' : 'text-slate-500 hover:bg-slate-900/80 hover:text-slate-200'}`}>
    <div className={`shrink-0 transition-transform duration-500 ${active ? 'scale-110' : 'group-hover:scale-110'}`}>{icon}</div>
    <span className="font-bold text-sm hidden md:block tracking-tight">{label}</span>
  </button>
);

const TaskRow: React.FC<{ task: Task, onToggle: (id: string) => void }> = ({ task, onToggle }) => (
  <div className={`glass p-6 rounded-[2rem] flex items-center gap-6 group hover:border-indigo-500/30 transition-all duration-500 ${task.completed ? 'opacity-40' : 'hover:translate-x-1'}`}>
    <button onClick={() => onToggle(task.id)} className={`w-8 h-8 rounded-xl border-2 flex items-center justify-center transition-all duration-500 ${task.completed ? 'bg-indigo-600 border-indigo-600 rotate-[360deg]' : 'border-slate-800 group-hover:border-indigo-500/50 hover:bg-indigo-500/10'}`}>
      {task.completed && <CheckCircle2 className="w-5 h-5 text-white" />}
    </button>
    <div className="flex-1">
      <h4 className={`font-bold text-lg tracking-tight ${task.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>{task.title}</h4>
      <div className="flex items-center gap-4 text-xs text-slate-500 mt-2 font-medium">
        <span className="flex items-center gap-2"><Clock className="w-3.5 h-3.5" /> {new Date(task.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        <span className="w-1 h-1 rounded-full bg-slate-800"></span>
        <span className={`px-3 py-1 rounded-full uppercase tracking-widest text-[10px] ${task.category === 'work' ? 'bg-indigo-500/10 text-indigo-400' : 'bg-emerald-500/10 text-emerald-400'}`}>{task.category}</span>
      </div>
    </div>
  </div>
);

const EmailCard: React.FC<{ email: Email }> = ({ email }) => (
  <div className="glass p-8 rounded-[3rem] border-slate-800/50 hover:border-indigo-500/20 transition-all duration-700 group relative overflow-hidden">
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-5">
        <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center font-black text-xl text-indigo-500 group-hover:scale-105 transition-transform duration-500">{email.sender[0]}</div>
        <div>
          <h4 className="font-bold text-lg text-white">{email.sender}</h4>
          <p className="text-sm text-slate-500 font-medium">{email.subject}</p>
        </div>
      </div>
      <div className="text-right"><span className="text-xs text-slate-600 font-bold uppercase tracking-widest">{new Date(email.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div>
    </div>
    <p className="text-slate-400 leading-relaxed text-sm mb-8 line-clamp-3">{email.content}</p>
    {email.draft && (
      <div className="bg-indigo-500/5 border border-indigo-500/10 p-6 rounded-[2.5rem] relative animate-in fade-in slide-in-from-bottom-2">
        <div className="flex items-center gap-3 text-[10px] text-indigo-400 font-black uppercase tracking-[0.2em] mb-4"><Sparkles className="w-4 h-4" /> Aura Suggested Response</div>
        <p className="text-slate-200 text-sm italic leading-loose">"{email.draft}"</p>
        <div className="flex justify-end gap-3 mt-6"><button className="px-8 py-3 rounded-xl bg-indigo-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-indigo-500 transition-all flex items-center gap-3 shadow-xl shadow-indigo-500/10"><Send className="w-4 h-4" /> Send Now</button></div>
      </div>
    )}
  </div>
);

const LinkedInCard: React.FC<{ item: LinkedInUpdate }> = ({ item }) => (
  <div className={`glass p-8 rounded-[3rem] border-slate-800 relative overflow-hidden transition-all duration-700 hover:translate-y-[-4px] ${item.highlighted ? 'ring-1 ring-indigo-500/30' : ''}`}>
    {item.highlighted && <div className="absolute top-0 right-0 bg-indigo-500 text-white px-5 py-2 text-[10px] font-black uppercase tracking-[0.2em]">Priority Highlight</div>}
    <div className="flex items-start justify-between mb-4">
      <div>
        <h4 className="font-black text-xl text-white mb-1 leading-tight">{item.title}</h4>
        {item.company && <p className="text-indigo-400 text-sm font-black uppercase tracking-widest">{item.company}</p>}
      </div>
    </div>
    <p className="text-sm text-slate-500 leading-relaxed mb-8">{item.description}</p>
    <div className="flex gap-4">
      <button className="flex-1 bg-slate-900 border border-slate-800 hover:bg-slate-800 py-4 rounded-2xl text-xs font-bold uppercase tracking-widest transition-all text-white">View Details</button>
      {item.type === 'job' && <button className="flex-1 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 py-4 rounded-2xl text-xs font-bold uppercase tracking-widest transition-all text-white shadow-xl shadow-indigo-500/10">Quick Apply</button>}
    </div>
  </div>
);

export default App;
