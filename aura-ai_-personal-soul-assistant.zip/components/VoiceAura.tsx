
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage, Type, FunctionDeclaration } from '@google/genai';
import { Mic, MicOff, Volume2, User, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import { decode, encode, decodeAudioData } from '../utils/audio';
import { UserProfile } from '../types';
import { auraTools } from '../services/geminiService';

interface Props {
  user: UserProfile;
  onNavigate?: (tab: 'dash' | 'calendar' | 'email' | 'linkedin' | 'chat') => void;
  onUpdateMemory?: (fact: string) => void;
  onToolCall?: (name: string, args: any) => Promise<any>;
}

const VoiceAura: React.FC<Props> = ({ user, onNavigate, onUpdateMemory, onToolCall }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [auraTranscript, setAuraTranscript] = useState('');
  const [userTranscript, setUserTranscript] = useState('');
  const [permissionError, setPermissionError] = useState<string | null>(null);

  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const stopSession = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    setIsActive(false);
    setIsConnecting(false);
    setIsSpeaking(false);
    setUserTranscript('');
    setAuraTranscript('');
    sourcesRef.current.forEach(source => { try { source.stop(); } catch (e) {} });
    sourcesRef.current.clear();
  }, []);

  const startSession = async () => {
    if (isActive) { stopSession(); return; }
    setIsConnecting(true);
    setPermissionError(null);
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    if (!audioContextRef.current) {
      audioContextRef.current = {
        input: new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 }),
        output: new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 })
      };
    }

    const { input, output } = audioContextRef.current;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          tools: [{ functionDeclarations: auraTools }],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          systemInstruction: `You are Aura, ${user.name}'s Soul Companion. RESPONSE TIME: Instant. STYLE: Snappy, warm, human. Context: ${user.memories.join(', ')}. Use your tools to manage the calendar, email, and LinkedIn. Talk like a human friend, not a robot.`,
          outputAudioTranscription: {},
          inputAudioTranscription: {}, 
        },
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            const source = input.createMediaStreamSource(stream);
            const scriptProcessor = input.createScriptProcessor(1024, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              sessionPromise.then(s => s.sendRealtimeInput({ media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' } }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(input.destination);
          },
          onmessage: async (m: LiveServerMessage) => {
            if (m.serverContent?.inputTranscription) {
              setUserTranscript(m.serverContent.inputTranscription.text);
            }
            if (m.serverContent?.outputTranscription) {
              setAuraTranscript(prev => (prev + ' ' + m.serverContent?.outputTranscription?.text).slice(-50));
            }
            if (m.toolCall) {
              for (const fc of m.toolCall.functionCalls) {
                let result = "Action executed.";
                
                if (fc.name === 'navigateToTab' && onNavigate) {
                  onNavigate(fc.args.tab as any);
                } else if (fc.name === 'updateUserMemory' && onUpdateMemory) {
                  onUpdateMemory(fc.args.fact as string);
                } else if (onToolCall) {
                  const res = await onToolCall(fc.name, fc.args);
                  result = res?.result || result;
                }

                sessionPromise.then(s => s.sendToolResponse({ 
                  functionResponses: [{ id: fc.id, name: fc.name, response: { result } }] 
                }));
              }
            }
            const base64Audio = m.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              setIsSpeaking(true);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, output.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), output, 24000, 1);
              const source = output.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(output.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsSpeaking(false);
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }
            if (m.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => { try { s.stop(); } catch(e){} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsSpeaking(false);
            }
            if (m.serverContent?.turnComplete) {
              setAuraTranscript('');
              setUserTranscript('');
            }
          },
          onerror: (e) => { setPermissionError("Connection Lost."); stopSession(); },
          onclose: () => stopSession()
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) { setIsConnecting(false); setIsActive(false); }
  };

  return (
    <div className="flex items-center gap-3 px-2">
      <div 
        className={`relative w-12 h-12 rounded-full flex items-center justify-center cursor-pointer transition-all duration-500 ${isActive ? 'bg-indigo-600' : 'bg-slate-800 hover:bg-slate-700 border border-slate-700'}`} 
        onClick={startSession}
      >
        {isActive && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className={`absolute inset-0 bg-indigo-400 opacity-30 rounded-full ${isSpeaking ? 'animate-ping' : 'animate-pulse'}`} />
          </div>
        )}
        {isConnecting ? <RefreshCw className="w-5 h-5 animate-spin text-white opacity-50" /> : <Mic className={`w-5 h-5 text-white z-10 ${isActive ? 'scale-110' : 'opacity-70'}`} />}
      </div>
      
      <div className="hidden lg:flex flex-col min-w-[120px]">
        <p className={`text-[9px] font-black uppercase tracking-widest ${isActive ? 'text-indigo-400' : 'text-slate-600'}`}>
          {isActive ? (isSpeaking ? 'Aura Syncing...' : 'Aura Listening') : 'Neural Voice Link'}
        </p>
        <p className="text-[10px] text-slate-400 truncate max-w-[150px] font-medium">
          {userTranscript ? `"${userTranscript}"` : (isActive ? 'Ready for command...' : 'Offline')}
        </p>
      </div>
    </div>
  );
};

export default VoiceAura;
