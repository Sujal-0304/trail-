
import React, { useEffect, useRef, useState } from 'react';
import { Task } from '../types';
import { Bell, X } from 'lucide-react';

interface Props {
  tasks: Task[];
}

interface Toast {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'urgent';
}

const ReminderSystem: React.FC<Props> = ({ tasks }) => {
  const notifiedRef = useRef<Set<string>>(new Set());
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const checkReminders = () => {
      const now = new Date();
      tasks.forEach(task => {
        if (task.completed) return;
        
        const startTime = new Date(task.startTime);
        const diffMs = startTime.getTime() - now.getTime();
        const diffSecs = Math.floor(diffMs / 1000);
        const diffMins = Math.floor(diffSecs / 60);

        // 5-10 min reminder (Trigger once when entering this window)
        // Check for 6-10 to be safe with 10s intervals
        if (diffMins >= 5 && diffMins <= 10 && !notifiedRef.current.has(`${task.id}-long`)) {
          triggerReminder(
            task.id,
            'long',
            `Aura Briefing: ${task.title}`,
            `This event starts in about ${diffMins} minutes.`,
            'info'
          );
        }

        // 1 min reminder (Trigger once when entering the final minute)
        if (diffSecs <= 65 && diffSecs > 0 && !notifiedRef.current.has(`${task.id}-short`)) {
          triggerReminder(
            task.id,
            'short',
            `Ready?`,
            `${task.title} is starting in 1 minute.`,
            'urgent'
          );
        }
      });
    };

    const interval = setInterval(checkReminders, 5000); // Tighter 5s check
    return () => clearInterval(interval);
  }, [tasks]);

  const triggerReminder = (taskId: string, type: string, title: string, body: string, toastType: 'info' | 'urgent') => {
    notifiedRef.current.add(`${taskId}-${type}`);
    
    // Browser Native Notification
    if ("Notification" in window && Notification.permission === "granted") {
      try {
        new Notification(title, { body, icon: '/favicon.ico' });
      } catch (e) {
        console.warn("Notification error:", e);
      }
    }

    // In-App Toast
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, title, body, type: toastType }]);
    
    // Auto remove toast after 12s
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 12000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="fixed top-6 right-6 z-[100] flex flex-col gap-3 pointer-events-none">
      {toasts.map(toast => (
        <div 
          key={toast.id}
          className={`pointer-events-auto w-80 glass p-5 rounded-2xl shadow-2xl border-l-4 flex gap-4 animate-in slide-in-from-right-10 duration-500 ${toast.type === 'urgent' ? 'border-amber-500 bg-amber-500/10' : 'border-indigo-500 bg-indigo-500/10'}`}
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${toast.type === 'urgent' ? 'bg-amber-500' : 'bg-indigo-500'}`}>
            <Bell className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-sm text-white truncate">{toast.title}</h4>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">{toast.body}</p>
          </div>
          <button onClick={() => removeToast(toast.id)} className="text-slate-500 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};

export default ReminderSystem;
