
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, Brain, AlertCircle, RefreshCw, Camera, Globe, Volume2, X, Zap } from 'lucide-react';
import { askAura, searchAura, analyzeImage, speakText } from '../services/geminiService';
import { UserProfile, ChatMessage } from '../types';

interface Props {
  user: UserProfile;
  onUpdateMemory: (fact: string) => void;
  onToolCall?: (name: string, args: any) => Promise<any>;
}

const ChatAura: React.FC<Props> = ({ user, onUpdateMemory, onToolCall }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: `Hello ${user.name}. My neural core is active. I can manage your calendar, email, and LinkedIn through our unified API link.` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useSearch, setUseSearch] = useState(false);
  const [useThinking, setUseThinking] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{data: string, type: string} | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isLoading]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImage({ data: (reader.result as string).split(',')[1], type: file.type });
      reader.readAsDataURL(file);
    }
  };

  const handleSpeak = async (text: string) => {
    try {
      const buffer = await speakText(text);
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.start(0);
    } catch (e) {
      console.error("TTS failed", e);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !selectedImage) || isLoading) return;

    const userMsg = input.trim();
    const currentImg = selectedImage;
    const thinkingActive = useThinking;
    
    setInput('');
    setSelectedImage(null);
    setMessages(prev => [...prev, { role: 'user', content: userMsg || "Analyzing image..." }]);
    setIsLoading(true);

    try {
      let response = "";
      if (currentImg) {
        response = await analyzeImage(userMsg || "What is in this image?", currentImg.data, currentImg.type);
      } else if (useSearch) {
        const searchRes = await searchAura(userMsg);
        response = searchRes.text;
      } else {
        response = await askAura(userMsg, user, { thinking: thinkingActive }, onToolCall);
      }
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (err: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: "I'm having a small connection issue with the neural link. Let's try that again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[700px] glass rounded-[3rem] border-indigo-500/10 overflow-hidden shadow-2xl relative">
      <div className="px-10 py-6 border-b border-slate-800/50 flex flex-wrap items-center justify-between gap-4 bg-slate-900/20">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-500/10 rounded-2xl"><Brain className="w-6 h-6 text-indigo-400" /></div>
          <div>
            <h3 className="text-xl font-bold font-outfit text-white">Neural Link</h3>
            <p className="text-[10px] text-indigo-400 font-black uppercase tracking-widest">Database & API Synced</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setUseThinking(!useThinking)} 
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition-all ${useThinking ? 'bg-amber-600 border-amber-500 text-white shadow-lg shadow-amber-500/20' : 'border-slate-800 text-slate-500 hover:text-slate-300'}`}
          >
            <Zap className={`w-4 h-4 ${useThinking ? 'animate-pulse' : ''}`} />
            <span className="text-[10px] font-bold uppercase tracking-widest">Thinking Mode</span>
          </button>
          
          <button 
            onClick={() => setUseSearch(!useSearch)} 
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition-all ${useSearch ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-slate-800 text-slate-500 hover:text-slate-300'}`}
          >
            <Globe className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Search</span>
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-8">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex items-start gap-5 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-indigo-600' : 'bg-slate-800'}`}>
              {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Sparkles className="w-5 h-5 text-indigo-400" />}
            </div>
            <div className={`relative group max-w-[80%] px-8 py-5 rounded-[2.5rem] text-sm leading-relaxed ${msg.role === 'user' ? 'bg-indigo-500/10 text-indigo-100 rounded-tr-none border border-indigo-500/10' : 'bg-slate-900/50 text-slate-300 rounded-tl-none border border-slate-800 shadow-inner shadow-black/20'}`}>
              <p className="whitespace-pre-wrap">{msg.content}</p>
              {msg.role === 'assistant' && (
                <button 
                  onClick={() => handleSpeak(msg.content)} 
                  className="absolute -right-12 top-2 p-2 rounded-full opacity-0 group-hover:opacity-100 hover:bg-slate-800 transition-all text-indigo-400"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-start gap-5 animate-pulse">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-indigo-500" />
            </div>
            <div className={`px-8 py-5 rounded-[2.5rem] rounded-tl-none border ${useThinking ? 'border-amber-500/30 bg-amber-500/5' : 'border-slate-800 bg-slate-900/50'}`}>
              <div className="flex gap-2 items-center">
                <div className="flex gap-1">
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '200ms' }} />
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '400ms' }} />
                </div>
                {useThinking && <span className="text-[10px] text-amber-500 font-black uppercase tracking-widest ml-2">Deep Reasoning...</span>}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-8 border-t border-slate-800/50 bg-slate-900/20">
        {selectedImage && (
          <div className="mb-4 flex items-center gap-4 animate-in fade-in slide-in-from-bottom-2">
            <div className="relative w-16 h-16 rounded-xl overflow-hidden border border-indigo-500">
              <img src={`data:${selectedImage.type};base64,${selectedImage.data}`} className="w-full h-full object-cover" />
              <button onClick={() => setSelectedImage(null)} className="absolute top-0 right-0 p-1 bg-red-500 text-white"><X className="w-3 h-3" /></button>
            </div>
            <p className="text-[10px] text-slate-400 font-bold uppercase">Multimodal Ready</p>
          </div>
        )}
        <form onSubmit={handleSubmit} className="relative flex items-center gap-4">
          <button type="button" onClick={() => fileInputRef.current?.click()} className="p-4 bg-slate-800 hover:bg-slate-700 rounded-2xl text-slate-400 transition-colors">
            <Camera className="w-6 h-6" />
          </button>
          <input type="file" ref={fileInputRef} onChange={handleImageSelect} className="hidden" accept="image/*" />
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={useThinking ? "High-budget processing..." : "Command Aura... I'll execute via API link."} 
            className={`flex-1 bg-slate-950 border rounded-3xl pl-8 pr-16 py-5 outline-none transition-all text-white ${useThinking ? 'border-amber-500/50 focus:ring-2 focus:ring-amber-500' : 'border-slate-800 focus:ring-2 focus:ring-indigo-500'}`}
          />
          <button type="submit" className={`absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-2xl text-white transition-all ${useThinking ? 'bg-amber-600 hover:bg-amber-500' : 'bg-indigo-600 hover:bg-indigo-500'}`}>
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatAura;
