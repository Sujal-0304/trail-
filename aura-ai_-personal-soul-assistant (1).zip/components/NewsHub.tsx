
import React, { useState, useEffect } from 'react';
import { Newspaper, RefreshCw, ExternalLink, Globe, Sparkles, Search, TrendingUp, Info, AlertCircle } from 'lucide-react';
import { UserProfile } from '../types';
import { getLatestNews } from '../services/geminiService';

interface Props {
  user: UserProfile;
}

const NewsHub: React.FC<Props> = ({ user }) => {
  const [newsText, setNewsText] = useState('');
  const [sources, setSources] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchNews = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getLatestNews(user);
      setNewsText(res.text);
      setSources(res.sources);
    } catch (err: any) {
      console.error(err);
      setError("I encountered a neural block while scanning global headlines. Let's try establish a new connection.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [user.preferences]);

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-fuchsia-500/10 rounded-[1.5rem] border border-fuchsia-500/20 shadow-xl shadow-fuchsia-500/5">
            <Newspaper className="w-8 h-8 text-fuchsia-400" />
          </div>
          <div>
            <h2 className="text-3xl font-black font-outfit text-white tracking-tight">News Hub</h2>
            <p className="text-[10px] text-fuchsia-400 font-black uppercase tracking-[0.3em]">Neural Grounding v1.0</p>
          </div>
        </div>
        <button 
          onClick={fetchNews} 
          disabled={loading}
          className={`p-4 rounded-2xl glass hover:bg-slate-800 transition-all ${loading ? 'animate-spin text-fuchsia-400' : 'text-slate-400'}`}
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <section className="glass p-12 rounded-[3.5rem] relative overflow-hidden group border-fuchsia-500/10 shadow-2xl">
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-fuchsia-500/5 rounded-full blur-[80px]" />
            <div className="flex items-center gap-3 mb-8">
              <Sparkles className="w-5 h-5 text-fuchsia-400" />
              <h3 className="text-xs font-black uppercase text-slate-400 tracking-[0.2em]">Tailored Daily Digest</h3>
            </div>
            
            {loading ? (
              <div className="space-y-6 animate-pulse">
                <div className="h-4 bg-slate-800 rounded-full w-3/4" />
                <div className="h-4 bg-slate-800 rounded-full w-1/2" />
                <div className="h-4 bg-slate-800 rounded-full w-5/6" />
                <div className="h-4 bg-slate-800 rounded-full w-2/3" />
              </div>
            ) : error ? (
              <div className="flex items-center gap-4 p-8 bg-red-500/10 border border-red-500/20 rounded-3xl">
                <AlertCircle className="w-6 h-6 text-red-500" />
                <p className="text-red-200 text-sm font-medium">{error}</p>
              </div>
            ) : (
              <div className="prose prose-invert prose-fuchsia max-w-none">
                <p className="whitespace-pre-wrap text-slate-200 leading-[1.8] text-lg font-medium drop-shadow-sm">
                  {newsText}
                </p>
              </div>
            )}
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 px-6">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-black uppercase text-slate-500 tracking-[0.2em]">Live Grounding Sources</h3>
            </div>
            <div className="grid gap-4">
              {sources.length > 0 ? sources.map((chunk, idx) => (
                <a 
                  key={idx} 
                  href={chunk.web?.uri} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="glass p-6 rounded-[2rem] flex items-center justify-between hover:bg-slate-900/60 hover:border-fuchsia-500/30 transition-all duration-500 group"
                >
                  <div className="flex items-center gap-5">
                    <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center text-fuchsia-500 font-black shrink-0 group-hover:scale-105 transition-transform">
                      <Globe className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-sm font-bold text-slate-200 truncate pr-4">{chunk.web?.title || "External Source"}</h4>
                      <p className="text-[10px] text-slate-500 font-bold uppercase truncate mt-1">{new URL(chunk.web?.uri).hostname}</p>
                    </div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-fuchsia-400 transition-colors" />
                </a>
              )) : !loading && (
                <div className="glass p-10 rounded-[3rem] text-center">
                  <p className="text-slate-500 text-sm italic">Direct grounding links will appear here after analysis.</p>
                </div>
              )}
            </div>
          </section>
        </div>

        <div className="space-y-8">
          <section className="glass p-8 rounded-[3rem] border-emerald-500/10 bg-emerald-500/5 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Info className="w-20 h-20 text-emerald-500" />
            </div>
            <h3 className="text-xs font-black uppercase text-emerald-400 mb-6 flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> Your Interests
            </h3>
            <div className="flex flex-wrap gap-2">
              {user.preferences.length > 0 ? user.preferences.map((pref, i) => (
                <span key={i} className="px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl text-[10px] font-black uppercase tracking-widest">
                  {pref}
                </span>
              )) : (
                <p className="text-xs text-slate-500 italic">No specific neural tags found. Scanning general global stream.</p>
              )}
            </div>
            <p className="text-[10px] text-slate-500 mt-8 leading-relaxed font-bold uppercase tracking-tighter">
              News is updated via Gemini Search tools. Results are fetched in real-time.
            </p>
          </section>

          <section className="glass p-8 rounded-[3rem] border-fuchsia-500/10 bg-fuchsia-500/5">
            <h3 className="text-xs font-black uppercase text-fuchsia-400 mb-4 flex items-center gap-2">
              <Search className="w-4 h-4" /> Search Engine
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-6 font-medium">
              Aura uses grounding to verify facts against live web data. Summaries are synthesized based on current trending events within the last 12-24 hours.
            </p>
            <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-fuchsia-500 w-full animate-pulse" />
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default NewsHub;
