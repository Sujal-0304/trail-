
import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, Brain, Camera, Globe, Volume2, X, Zap, Command, MessageSquare } from 'lucide-react';
import { askAura, searchAura, analyzeImage, speakText } from '../services/geminiService';
import { UserProfile, ChatMessage } from '../types';

interface Props {
  user: UserProfile;
  onUpdateMemory: (fact: string) => void;
  onToolCall?: (name: string, args: any) => Promise<any>;
}

const ChatAura: React.FC<Props> = ({ user, onUpdateMemory, onToolCall }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: `Hello ${user.name}. I am your neural companion. I can manage your schedule, search the web, or just chat. How can I assist you today?` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useSearch, setUseSearch] = useState(false);
  const [useThinking, setUseThinking] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{data: string, type: string} | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isLoading]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImage({ data: (reader.result as string).split(',')[1], type: file.type });
      reader.readAsDataURL(file);
    }
  };

  const handleSpeak = async (text: string) => {
    try {
      const buffer = await speakText(text);
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.start(0);
    } catch (e) {
      console.error("TTS failed", e);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !selectedImage) || isLoading) return;

    const userMsg = input.trim();
    const isWakeTriggered = userMsg.toLowerCase().startsWith('aura');
    const currentImg = selectedImage;
    const thinkingActive = useThinking;
    
    setInput('');
    setSelectedImage(null);
    setMessages(prev => [...prev, { role: 'user', content: userMsg || "Analyzing image..." }]);
    setIsLoading(true);

    try {
      let response = "";
      if (currentImg) {
        response = await analyzeImage(userMsg || "What is in this image?", currentImg.data, currentImg.type);
      } else if (useSearch) {
        const searchRes = await searchAura(userMsg);
        response = searchRes.text;
      } else {
        response = await askAura(userMsg, user, { thinking: thinkingActive }, onToolCall);
      }
      
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      if (isWakeTriggered) handleSpeak(response);
      
    } catch (err: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: "Neural link interrupted. Re-syncing..." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] max-w-5xl mx-auto relative animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* HEADER OVERLAY */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-slate-950/20 backdrop-blur-md rounded-t-[2rem]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-fuchsia-500/10 rounded-lg flex items-center justify-center border border-fuchsia-500/20">
            <MessageSquare className="w-4 h-4 text-fuchsia-400" />
          </div>
          <span className="text-sm font-bold text-white tracking-tight">Intelligence v3.0</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setUseThinking(!useThinking)} className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all flex items-center gap-2 ${useThinking ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-slate-500 border border-white/5'}`}>
            <Zap className="w-3 h-3" /> Thinking
          </button>
          <button onClick={() => setUseSearch(!useSearch)} className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all flex items-center gap-2 ${useSearch ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' : 'text-slate-500 border border-white/5'}`}>
            <Globe className="w-3 h-3" /> Search
          </button>
        </div>
      </div>

      {/* MESSAGES AREA */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 py-10 space-y-10">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex items-start gap-6 ${msg.role === 'user' ? 'flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-2 duration-500`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${msg.role === 'user' ? 'bg-fuchsia-600 border-fuchsia-400 shadow-lg shadow-fuchsia-500/20' : 'bg-slate-900 border-slate-800'}`}>
              {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Sparkles className="w-4 h-4 text-fuchsia-400" />}
            </div>
            <div className={`group relative max-w-[75%] px-6 py-4 rounded-3xl text-sm leading-relaxed shadow-sm ${msg.role === 'user' ? 'bg-fuchsia-600 text-white rounded-tr-none' : 'bg-slate-900/50 text-slate-200 border border-white/5 rounded-tl-none'}`}>
              <p className="whitespace-pre-wrap">{msg.content}</p>
              {msg.role === 'assistant' && (
                <button onClick={() => handleSpeak(msg.content)} className="absolute -right-10 bottom-2 p-2 rounded-full opacity-0 group-hover:opacity-100 hover:bg-white/5 transition-all text-fuchsia-400">
                  <Volume2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-start gap-6 animate-pulse">
            <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center"><Sparkles className="w-4 h-4 text-fuchsia-500" /></div>
            <div className="px-6 py-4 rounded-3xl bg-slate-900/50 border border-white/5 flex gap-1.5 items-center">
              <div className="w-1.5 h-1.5 bg-fuchsia-500/50 rounded-full animate-bounce" />
              <div className="w-1.5 h-1.5 bg-fuchsia-500/50 rounded-full animate-bounce delay-100" />
              <div className="w-1.5 h-1.5 bg-fuchsia-500/50 rounded-full animate-bounce delay-200" />
            </div>
          </div>
        )}
      </div>

      {/* INPUT AREA */}
      <div className="px-6 pb-10">
        <div className="max-w-4xl mx-auto glass p-2 rounded-[2.5rem] relative shadow-2xl">
          {selectedImage && (
            <div className="absolute -top-20 left-4 p-2 glass rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4">
              <div className="w-12 h-12 rounded-xl overflow-hidden"><img src={`data:${selectedImage.type};base64,${selectedImage.data}`} className="w-full h-full object-cover" /></div>
              <button onClick={() => setSelectedImage(null)} className="p-1.5 bg-red-500/20 text-red-400 rounded-full hover:bg-red-500/30"><X className="w-3 h-3" /></button>
            </div>
          )}
          <form onSubmit={handleSubmit} className="relative flex items-center gap-2">
            <button type="button" onClick={() => fileInputRef.current?.click()} className="p-4 text-slate-500 hover:text-white transition-colors"><Camera className="w-5 h-5" /></button>
            <input type="file" ref={fileInputRef} onChange={handleImageSelect} className="hidden" accept="image/*" />
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder='Ask anything...' 
              className="flex-1 bg-transparent border-none px-4 py-4 text-sm text-white outline-none placeholder:text-slate-600"
            />
            <button type="submit" className="p-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-[1.8rem] text-white transition-all shadow-lg shadow-fuchsia-600/20">
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChatAura;
