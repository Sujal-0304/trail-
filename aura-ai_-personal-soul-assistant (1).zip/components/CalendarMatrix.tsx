
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, AlertCircle } from 'lucide-react';
import { Task } from '../types';

interface Props {
  tasks: Task[];
  importantDates: string[];
  onToggleImportant: (date: string) => void;
}

const CalendarMatrix: React.FC<Props> = ({ tasks, importantDates, onToggleImportant }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  const totalDays = daysInMonth(year, month);
  const startOffset = firstDayOfMonth(year, month);

  const days = Array.from({ length: totalDays }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: startOffset }, (_, i) => i);

  const isToday = (day: number) => {
    const today = new Date();
    return today.getDate() === day && today.getMonth() === month && today.getFullYear() === year;
  };

  const getDayTasks = (day: number) => {
    const dayStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return tasks.filter(t => t.startTime.startsWith(dayStr));
  };

  const isImportant = (day: number) => {
    const dayStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return importantDates.includes(dayStr);
  };

  return (
    <div className="flex flex-col gap-8 animate-in fade-in duration-700">
      <div className="flex items-center justify-between px-6">
        <div>
          <h2 className="text-3xl font-black font-outfit text-white tracking-tight">{monthName} <span className="text-cyan-500">{year}</span></h2>
          <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em]">Temporal Matrix View</p>
        </div>
        <div className="flex gap-2">
          <button onClick={prevMonth} className="p-4 rounded-2xl glass hover:bg-slate-800 transition-all text-slate-400"><ChevronLeft size={20} /></button>
          <button onClick={nextMonth} className="p-4 rounded-2xl glass hover:bg-slate-800 transition-all text-slate-400"><ChevronRight size={20} /></button>
        </div>
      </div>

      <div className="glass p-8 rounded-[3.5rem] border-white/5 shadow-2xl overflow-hidden relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-[100px] -mr-32 -mt-32" />
        
        <div className="grid grid-cols-7 gap-4 mb-6">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-center text-[10px] font-black uppercase text-slate-500 tracking-widest">{day}</div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-4">
          {emptyDays.map(i => <div key={`empty-${i}`} className="aspect-square rounded-3xl bg-transparent" />)}
          {days.map(day => {
            const dayTasks = getDayTasks(day);
            const important = isImportant(day);
            const dayStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

            return (
              <div 
                key={day}
                onClick={() => onToggleImportant(dayStr)}
                className={`group relative aspect-square rounded-[1.8rem] border flex flex-col p-4 transition-all duration-500 cursor-pointer overflow-hidden ${
                  isToday(day) 
                    ? 'bg-cyan-600/10 border-cyan-500/30' 
                    : 'bg-white/5 border-white/5 hover:border-cyan-500/20 hover:bg-white/10'
                } ${important ? 'ring-2 ring-cyan-500 shadow-lg shadow-cyan-500/20' : ''}`}
              >
                {important && <div className="absolute top-0 right-0 p-2"><Star className="w-3 h-3 text-cyan-400 fill-cyan-400" /></div>}
                
                <span className={`text-lg font-black font-outfit ${isToday(day) ? 'text-cyan-400' : 'text-white'}`}>{day}</span>
                
                <div className="mt-auto flex gap-1 flex-wrap">
                  {dayTasks.map((t, idx) => (
                    <div 
                      key={idx} 
                      className={`w-1.5 h-1.5 rounded-full ${
                        t.category === 'urgent' ? 'bg-red-500' : 
                        t.category === 'health' ? 'bg-emerald-500' : 
                        'bg-cyan-400'
                      }`} 
                    />
                  ))}
                </div>

                {/* Hover Details Overlay */}
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="text-[10px] font-black uppercase text-cyan-400 mb-2">Events: {dayTasks.length}</p>
                  <div className="flex-1 overflow-y-auto space-y-1">
                    {dayTasks.map((t, i) => (
                      <p key={i} className="text-[9px] text-slate-300 truncate font-bold">• {t.title}</p>
                    ))}
                    {important && <p className="text-[9px] text-amber-400 font-black uppercase mt-2">★ Important Day</p>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="glass p-8 rounded-[2.5rem] border-white/5">
           <h3 className="text-xs font-black uppercase text-slate-500 tracking-widest mb-6">Important Milestones</h3>
           <div className="space-y-4">
              {importantDates.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No days marked as important yet. Tell Aura to mark a day or click one above.</p>
              ) : (
                importantDates.sort().map(date => (
                  <div key={date} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 group hover:border-cyan-500/30 transition-all">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400"><Star size={16} fill="currentColor" /></div>
                      <div>
                        <p className="text-sm font-bold text-white">{new Date(date).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}</p>
                        <p className="text-[10px] text-slate-500 font-black uppercase tracking-tighter">Neural Marker Set</p>
                      </div>
                    </div>
                    <button onClick={() => onToggleImportant(date)} className="p-2 text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"><ChevronRight size={16} /></button>
                  </div>
                ))
              )}
           </div>
        </div>

        <div className="glass p-8 rounded-[2.5rem] border-amber-500/10 bg-amber-500/5">
          <div className="flex items-center gap-3 mb-4">
            <AlertCircle className="w-5 h-5 text-amber-500" />
            <h3 className="text-xs font-black uppercase text-amber-500 tracking-widest">Neural Tip</h3>
          </div>
          <p className="text-sm text-amber-200/70 leading-relaxed font-medium">
            You can synchronize days with your neural link. Just say, <span className="text-white font-bold">"Aura, mark October 24th as an important day"</span> and I will highlight it in your Matrix.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CalendarMatrix;
