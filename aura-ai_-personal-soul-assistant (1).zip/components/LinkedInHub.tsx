
import React from 'react';
import { Briefcase, Building2, ExternalLink, RefreshCw, Zap, Star, ShieldCheck } from 'lucide-react';
import { LinkedInUpdate } from '../types';

interface Props {
  updates: LinkedInUpdate[];
  onSync: () => void;
  loading: boolean;
}

const LinkedInHub: React.FC<Props> = ({ updates, onSync, loading }) => {
  return (
    <div className="space-y-12 animate-in fade-in duration-700 pb-12">
      <div className="flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-violet-500/10 rounded-[1.5rem] border border-violet-500/20 shadow-xl shadow-violet-500/5">
            <Briefcase className="w-8 h-8 text-violet-400" />
          </div>
          <div>
            <h2 className="text-3xl font-black font-outfit text-white tracking-tight">Professional Sync</h2>
            <p className="text-[10px] text-violet-400 font-black uppercase tracking-[0.3em]">Neural Career Radar</p>
          </div>
        </div>
        <button 
          onClick={onSync} 
          disabled={loading}
          className={`p-4 rounded-2xl glass hover:bg-slate-800 transition-all ${loading ? 'animate-spin text-violet-400' : 'text-slate-400'}`}
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8 space-y-8">
          <section className="space-y-6">
            <div className="flex items-center justify-between px-6">
              <h3 className="text-xs font-black uppercase text-slate-500 tracking-[0.2em]">Live Opportunities</h3>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span className="text-[9px] text-slate-500 font-bold uppercase">AI Verified</span>
              </div>
            </div>

            <div className="grid gap-6">
              {updates.length > 0 ? updates.map(update => (
                <div key={update.id} className={`glass p-8 rounded-[3rem] border-white/5 hover:border-violet-500/30 transition-all duration-500 group relative ${update.highlighted ? 'bg-violet-500/5 ring-1 ring-violet-500/20' : ''}`}>
                  {update.highlighted && (
                    <div className="absolute top-8 right-8 px-3 py-1 bg-violet-600 rounded-full text-[8px] font-black uppercase text-white shadow-lg shadow-violet-600/20 animate-pulse">
                      Top Match
                    </div>
                  )}
                  <div className="flex items-start gap-8">
                    <div className="w-16 h-16 rounded-3xl bg-slate-950 border border-slate-800 flex items-center justify-center text-violet-400 shrink-0 group-hover:scale-105 transition-transform">
                      {update.type === 'job' ? <Building2 className="w-7 h-7" /> : <Zap className="w-7 h-7" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xl font-bold text-white group-hover:text-violet-300 transition-colors truncate">{update.title}</h4>
                      <p className="text-sm text-violet-400 font-bold mt-1 uppercase tracking-wider">{update.company || "Notification"}</p>
                      <p className="text-slate-400 text-sm leading-relaxed mt-4 line-clamp-2">{update.description}</p>
                      
                      <div className="flex items-center gap-4 mt-8">
                        <button className="px-6 py-2.5 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-violet-600/10">
                          {update.type === 'job' ? 'Apply Now' : 'View Update'}
                        </button>
                        <button className="p-2.5 glass rounded-xl text-slate-500 hover:text-white transition-all">
                          <ExternalLink className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )) : (
                <div className="glass p-20 rounded-[4rem] text-center border-dashed border-white/10">
                  <p className="text-slate-500 text-sm italic">Scanning your neural link for career updates...</p>
                </div>
              )}
            </div>
          </section>
        </div>

        <div className="lg:col-span-4 space-y-10">
           <section className="glass p-10 rounded-[3.5rem] border-violet-500/10 bg-gradient-to-br from-violet-500/5 to-transparent">
              <h3 className="text-xs font-black uppercase text-violet-400 mb-8 flex items-center gap-2">
                <Star className="w-4 h-4 fill-violet-400" /> Career Insights
              </h3>
              <div className="space-y-6">
                <InsightCard label="Market Value" value="+12%" color="emerald" />
                <InsightCard label="Neural Compatibility" value="98.4%" color="violet" />
                <InsightCard label="Profile Strength" value="Elite" color="amber" />
              </div>
              <p className="text-[10px] text-slate-500 mt-10 leading-relaxed font-bold uppercase tracking-tighter">
                Based on your current role and memory context, Aura has optimized your visibility to high-tier recruiters.
              </p>
           </section>

           <section className="glass p-10 rounded-[3.5rem] border-amber-500/10 bg-amber-500/5">
              <h3 className="text-xs font-black uppercase text-amber-500 mb-4 flex items-center gap-2">
                <Zap className="w-4 h-4" /> Optimization Tip
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-medium">
                Your recent work on "Neural Core Review" matches several Senior Architect roles in the SF Bay Area. Would you like me to prepare a tailored cover letter?
              </p>
           </section>
        </div>
      </div>
    </div>
  );
};

const InsightCard: React.FC<{ label: string, value: string, color: string }> = ({ label, value, color }) => {
  const textColor = {
    violet: 'text-violet-400',
    emerald: 'text-emerald-400',
    amber: 'text-amber-400'
  }[color];
  return (
    <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
      <p className="text-[9px] font-black uppercase text-slate-500 tracking-widest mb-1">{label}</p>
      <p className={`text-xl font-black font-outfit ${textColor}`}>{value}</p>
    </div>
  );
};

export default LinkedInHub;
