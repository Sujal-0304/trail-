
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage, Type, FunctionDeclaration } from '@google/genai';
import { Mic, MicOff, Volume2, User, Sparkles, AlertCircle, RefreshCw, Key, ShieldAlert, ExternalLink } from 'lucide-react';
import { decode, encode, decodeAudioData } from '../utils/audio';
import { UserProfile } from '../types';
import { auraTools, getLatestNews } from '../services/geminiService';

interface Props {
  user: UserProfile;
  onNavigate?: (tab: 'dash' | 'calendar' | 'email' | 'linkedin' | 'chat' | 'news') => void;
  onUpdateMemory?: (fact: string) => void;
  onToolCall?: (name: string, args: any) => Promise<any>;
  autoStart?: boolean;
}

const VoiceAura: React.FC<Props> = ({ user, onNavigate, onUpdateMemory, onToolCall, autoStart }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [auraTranscript, setAuraTranscript] = useState('');
  const [userTranscript, setUserTranscript] = useState('');
  const [permissionError, setPermissionError] = useState<boolean>(false);

  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const inactivityTimerRef = useRef<number | null>(null);

  const stopSession = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
    setIsActive(false);
    setIsConnecting(false);
    setIsSpeaking(false);
    setUserTranscript('');
    setAuraTranscript('');
    sourcesRef.current.forEach(source => { try { source.stop(); } catch (e) {} });
    sourcesRef.current.clear();
  }, []);

  const handleSelectKey = async () => {
    try {
      if ((window as any).aistudio) {
        await (window as any).aistudio.openSelectKey();
        setPermissionError(false);
        // Per guidelines, assume success and try starting again
        setTimeout(() => startSession(), 500);
      }
    } catch (e) {
      console.error("Key selection failed", e);
    }
  };

  const resetInactivityTimer = useCallback(() => {
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
    }
    if (isActive) {
      inactivityTimerRef.current = window.setTimeout(() => {
        stopSession();
      }, 45000); // 45s listening window
    }
  }, [isActive, stopSession]);

  const startSession = async () => {
    if (isActive) { stopSession(); return; }
    
    // Check if we need to select a key first
    if ((window as any).aistudio && !(await (window as any).aistudio.hasSelectedApiKey())) {
      setPermissionError(true);
      return;
    }

    setIsConnecting(true);
    setPermissionError(false);
    
    // Always create new instance right before the call to ensure the latest API key is used
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    if (!audioContextRef.current) {
      audioContextRef.current = {
        input: new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 }),
        output: new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 })
      };
    }

    const { input, output } = audioContextRef.current;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          tools: [{ functionDeclarations: auraTools }],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          systemInstruction: `You are Aura, ${user.name}'s soul assistant. 
          Respond with extreme intelligence and warmth.
          You can navigate, remember facts, and manage tasks using your tools.`,
          outputAudioTranscription: {},
          inputAudioTranscription: {}, 
        },
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);
            const source = input.createMediaStreamSource(stream);
            const scriptProcessor = input.createScriptProcessor(1024, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              sessionPromise.then(s => s.sendRealtimeInput({ 
                media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' } 
              }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(input.destination);
          },
          onmessage: async (m: LiveServerMessage) => {
            resetInactivityTimer();
            if (m.serverContent?.inputTranscription) {
              setUserTranscript(m.serverContent.inputTranscription.text);
            }
            if (m.serverContent?.outputTranscription) {
              setAuraTranscript(prev => (prev + ' ' + m.serverContent?.outputTranscription?.text).slice(-100));
            }
            if (m.toolCall) {
              for (const fc of m.toolCall.functionCalls) {
                let result: any = "Executing...";
                if (fc.name === 'navigateToTab' && onNavigate) {
                  onNavigate(fc.args.tab as any);
                } else if (onToolCall) {
                  const res = await onToolCall(fc.name, fc.args);
                  result = res?.result || result;
                }
                sessionPromise.then(s => s.sendToolResponse({ 
                  functionResponses: { id: fc.id, name: fc.name, response: { result } } 
                }));
              }
            }
            const base64Audio = m.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              setIsSpeaking(true);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, output.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), output, 24000, 1);
              const source = output.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(output.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) {
                   setIsSpeaking(false);
                   resetInactivityTimer();
                }
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }
          },
          onerror: (e: any) => { 
            console.error('Session Error:', e);
            const msg = (e?.message || "").toLowerCase();
            if (msg.includes("permission") || msg.includes("403") || msg.includes("entity was not found")) {
              setPermissionError(true);
            }
            stopSession(); 
          },
          onclose: () => stopSession()
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err: any) { 
      console.error('Failed to start session:', err);
      const msg = (err.message || "").toLowerCase();
      if (msg.includes("permission") || msg.includes("403")) {
        setPermissionError(true);
      }
      setIsConnecting(false); 
      setIsActive(false); 
    }
  };

  useEffect(() => {
    if (autoStart && !isActive && !isConnecting) startSession();
  }, [autoStart]);

  return (
    <div className="flex items-center gap-4">
      <div 
        className={`relative w-14 h-14 rounded-full flex items-center justify-center cursor-pointer transition-all duration-500 shadow-2xl ${
          isActive ? 'bg-cyan-600' : 
          permissionError ? 'bg-red-600/20 border border-red-500 key-alert' : 
          'bg-slate-800 hover:bg-slate-700'
        }`} 
        onClick={permissionError ? handleSelectKey : startSession}
      >
        {isActive && (
          <div className="absolute inset-0">
            <div className={`absolute inset-0 bg-cyan-500/30 rounded-full ${isSpeaking ? 'animate-ping' : 'animate-pulse'}`} />
          </div>
        )}
        {isConnecting ? (
          <RefreshCw className="w-6 h-6 animate-spin text-white/50" />
        ) : permissionError ? (
          <ShieldAlert className="w-6 h-6 text-red-500" />
        ) : (
          <Mic className={`w-6 h-6 text-white ${isActive ? 'scale-110' : 'opacity-70'}`} />
        )}
      </div>
      
      <div className="hidden lg:flex flex-col">
        <p className={`text-[10px] font-black uppercase tracking-widest ${isActive ? 'text-cyan-400' : permissionError ? 'text-red-500' : 'text-slate-500'}`}>
          {isActive ? (isSpeaking ? 'Aura responding' : 'Aura listening') : permissionError ? 'Permission Denied' : 'Neural Link'}
        </p>
        <div className="flex flex-col">
          <p className="text-[11px] text-slate-300 font-medium max-w-[180px] truncate">
            {permissionError ? 'Select Paid API Key' : isActive ? userTranscript || 'Speak now...' : 'Tap mic to connect'}
          </p>
          {permissionError && (
            <a 
              href="https://ai.google.dev/gemini-api/docs/billing" 
              target="_blank" 
              className="text-[9px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-bold uppercase mt-0.5"
              onClick={(e) => e.stopPropagation()}
            >
              Billing Docs <ExternalLink size={10} />
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default VoiceAura;
