
import { UserProfile } from "../types";

/**
 * AuraDB: A simulated backend database using IndexedDB for persistent storage.
 * This ensures user information and memories are kept safely even after refresh/restart.
 */
class AuraDB {
  private dbName = "AuraCoreDB";
  private version = 1;
  private userStore = "users";

  private initDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onupgradeneeded = (event: any) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.userStore)) {
          db.createObjectStore(this.userStore, { keyPath: "name" });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async saveUser(user: UserProfile): Promise<void> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(this.userStore, "readwrite");
      const store = transaction.objectStore(this.userStore);
      const request = store.put(user);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getUser(name: string): Promise<UserProfile | null> {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(this.userStore, "readonly");
      const store = transaction.objectStore(this.userStore);
      const request = store.get(name);

      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async updateMemory(name: string, fact: string): Promise<UserProfile | null> {
    const user = await this.getUser(name);
    if (!user) return null;

    // Avoid duplicate memories
    if (!user.memories.includes(fact)) {
      user.memories.push(fact);
      await this.saveUser(user);
    }
    return user;
  }
}

export const auraDB = new AuraDB();
