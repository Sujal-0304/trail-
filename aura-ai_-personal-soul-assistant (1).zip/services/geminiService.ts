
import { GoogleGenAI, Type, Modality, FunctionDeclaration } from "@google/genai";
import { UserProfile, Email, Task } from "../types";
import { decode, encode, decodeAudioData } from "../utils/audio";

/**
 * Creates a fresh AI instance to ensure the latest API key is used.
 */
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

const getCurrentContext = () => {
  const now = new Date();
  return `Current Time: ${now.toLocaleTimeString()}. Current Date: ${now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.`;
};

// --- TOOL DECLARATIONS ---

export const auraTools: FunctionDeclaration[] = [
  {
    name: 'scheduleTask',
    parameters: {
      type: Type.OBJECT,
      description: 'Add a new task or appointment to the user calendar.',
      properties: {
        title: { type: Type.STRING },
        startTime: { type: Type.STRING, description: 'ISO string' },
        endTime: { type: Type.STRING, description: 'ISO string' },
        category: { type: Type.STRING, enum: ['work', 'personal', 'health', 'urgent'] }
      },
      required: ['title', 'startTime', 'endTime', 'category']
    }
  },
  {
    name: 'markDayImportant',
    parameters: {
      type: Type.OBJECT,
      description: 'Mark a specific date as important in the user calendar.',
      properties: {
        date: { type: Type.STRING, description: 'The date to mark as important in YYYY-MM-DD format.' },
        reason: { type: Type.STRING, description: 'The reason why this day is important (optional).' }
      },
      required: ['date']
    }
  },
  {
    name: 'sendEmail',
    parameters: {
      type: Type.OBJECT,
      description: 'Send an email to a recipient.',
      properties: {
        recipient: { type: Type.STRING },
        subject: { type: Type.STRING },
        body: { type: Type.STRING }
      },
      required: ['recipient', 'subject', 'body']
    }
  },
  {
    name: 'updateUserMemory',
    parameters: {
      type: Type.OBJECT,
      description: 'Store a fact about the user.',
      properties: { fact: { type: Type.STRING } },
      required: ['fact']
    }
  },
  {
    name: 'navigateToTab',
    parameters: {
      type: Type.OBJECT,
      description: 'Switch the application tab.',
      properties: { tab: { type: Type.STRING, enum: ['dash', 'calendar', 'email', 'linkedin', 'chat', 'news'] } },
      required: ['tab']
    }
  }
];

async function withRetry<T>(fn: () => Promise<T>, maxRetries = 2): Promise<T> {
  let lastError: any;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      const errorMsg = error?.message || (typeof error === 'object' ? JSON.stringify(error) : String(error));
      
      if (
        errorMsg.includes("403") || 
        errorMsg.toLowerCase().includes("permission") || 
        errorMsg.includes("Requested entity was not found") ||
        (error as any)?.status === 403
      ) {
        throw new Error("PERMISSION_DENIED");
      }

      if (errorMsg.includes("429") || (error as any)?.status === 429) {
        const delay = Math.pow(2, i) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw error;
    }
  }
  throw lastError;
}

export const askAura = async (
  prompt: string, 
  user: UserProfile, 
  options: { thinking: boolean } = { thinking: false }, 
  onToolCall?: (name: string, args: any) => Promise<any>
): Promise<string> => {
  return withRetry(async () => {
    const ai = getAI();
    const timeContext = getCurrentContext();
    const config: any = {
      tools: [{ functionDeclarations: auraTools }],
      systemInstruction: `You are Aura, an elite AI Chief of Staff and soulful personal companion for ${user.name}.
      Current Context: ${timeContext}
      ROLE: You provide high-end, proactive intelligence. Your reasoning is sophisticated, empathetic, and exceptionally precise.
      AUTONOMY: You have a complete free hand to manage ${user.name}'s life via your tools.
      USER MEMORIES: ${user.memories.join('; ')}.`
    };

    if (options.thinking) {
      config.thinkingConfig = { thinkingBudget: 32768 };
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config
    });

    if (response.functionCalls && onToolCall) {
      for (const fc of response.functionCalls) {
        await onToolCall(fc.name, fc.args);
      }
    }

    return response.text || "Synchronized.";
  });
};

export const searchAura = async (prompt: string): Promise<{text: string, sources: any[]}> => {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    return {
      text: response.text || "",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  });
};

export const getLatestNews = async (user: UserProfile): Promise<{text: string, sources: any[]}> => {
  return withRetry(async () => {
    const ai = getAI();
    const prompt = `Provide a premium news briefing for ${user.name}. Interests: ${user.preferences.join(', ')}. Date: ${new Date().toLocaleDateString()}.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });

    return {
      text: response.text || "Neural uplink stable, news stream empty.",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  });
};

export const analyzeImage = async (prompt: string, base64Image: string, mimeType: string): Promise<string> => {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { data: base64Image, mimeType } },
          { text: prompt }
        ]
      }
    });
    return response.text || "";
  });
};

export const speakText = async (text: string): Promise<AudioBuffer> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Speak warmly: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio generated");

  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  return await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
};

export const planDay = async (user: UserProfile, tasks: Task[]): Promise<string> => {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-flash-lite-latest',
      contents: `Plan ${user.name}'s day based on tasks: ${JSON.stringify(tasks)}. Use a poetic yet efficient tone.`,
    });
    return response.text || "";
  });
};

export const categorizeEmails = async (emails: any[]): Promise<Email[]> => {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-flash-lite-latest',
      contents: `Process these emails: ${JSON.stringify(emails)}. Return JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              sender: { type: Type.STRING },
              subject: { type: Type.STRING },
              content: { type: Type.STRING },
              timestamp: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['main', 'spam'] }
            },
            required: ["id", "type"]
          }
        }
      }
    });
    return JSON.parse(response.text);
  });
};

export const generateLinkedInInsights = async (user: UserProfile): Promise<any> => {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-flash-lite-latest',
      contents: `Generate insights for ${user.role}. Return JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            updates: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  type: { type: Type.STRING },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  highlighted: { type: Type.BOOLEAN }
                }
              }
            }
          }
        }
      }
    });
    return JSON.parse(response.text);
  });
};
